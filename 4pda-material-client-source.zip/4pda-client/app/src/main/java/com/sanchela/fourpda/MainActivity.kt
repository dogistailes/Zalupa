package com.sanchela.fourpda

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat

private const val HOME_URL = "https://4pda.to/"
private val LightScheme = lightColorScheme(
    primary = Color(0xFF4658A9), onPrimary = Color.White,
    secondaryContainer = Color(0xFFE3E7FF), onSecondaryContainer = Color(0xFF17245E),
    background = Color(0xFFF7F7FF), surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFECEEF8), onSurface = Color(0xFF191B22),
    onSurfaceVariant = Color(0xFF5F6270), outline = Color(0xFFC5C7D5)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFB8C4FF), onPrimary = Color(0xFF202D70),
    secondaryContainer = Color(0xFF303A68), onSecondaryContainer = Color(0xFFE0E4FF),
    background = Color(0xFF111318), surface = Color(0xFF1B1D24),
    surfaceVariant = Color(0xFF292C34), onSurface = Color(0xFFE3E2EA),
    onSurfaceVariant = Color(0xFFBFC2D0), outline = Color(0xFF444752)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        CookieManager.getInstance().setAcceptCookie(true)
        setContent { FourPdaApp() }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun FourPdaApp() {
    var dark by remember { mutableStateOf(false) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("4PDA") }
    var progress by remember { mutableIntStateOf(0) }
    var currentUrl by remember { mutableStateOf(HOME_URL) }

    BackHandler(enabled = webView?.canGoBack() == true) { webView?.goBack() }

    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(42.dp),
                                shape = RoundedCornerShape(15.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("4P", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text("4PDA", style = MaterialTheme.typography.titleLarge)
                                Text(pageTitle.take(48), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            }
                            IconButton(onClick = { dark = !dark }) {
                                Text(if (dark) "☼" else "☾", style = MaterialTheme.typography.titleLarge)
                            }
                        }
                        if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                    }
                }
            },
            bottomBar = {
                Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 6.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NavAction("Назад", { webView?.goBack() }, enabled = webView?.canGoBack() == true, icon = { Icon(Icons.Default.ArrowBack, null) })
                        NavAction("Вперёд", { webView?.goForward() }, enabled = webView?.canGoForward() == true, icon = { Icon(Icons.Default.ArrowForward, null) })
                        NavAction("Главная", { webView?.loadUrl(HOME_URL) }, icon = { Icon(Icons.Default.Home, null) })
                        NavAction("Поиск", { webView?.evaluateJavascript("(function(){var x=document.querySelector('input[type=search],input[name=q],input[name=search]');if(x){x.focus()}else{window.scrollTo(0,0)}})()", null) }, icon = { Icon(Icons.Default.Search, null) })
                        NavAction("Обновить", { webView?.reload() }, icon = { Icon(Icons.Default.Refresh, null) })
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            AndroidView(
                modifier = Modifier.fillMaxSize().padding(padding),
                factory = { context ->
                    WebView(context).apply {
                        webView = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.javaScriptCanOpenWindowsAutomatically = false
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) { progress = newProgress }
                            override fun onReceivedTitle(view: WebView?, title: String?) { pageTitle = title?.ifBlank { "4PDA" } ?: "4PDA" }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val url = request?.url?.toString() ?: return false
                                return !(url.startsWith("https://") || url.startsWith("http://"))
                            }
                            override fun onPageFinished(view: WebView?, url: String?) {
                                currentUrl = url ?: HOME_URL
                                CookieManager.getInstance().flush()
                            }
                        }
                        loadUrl(HOME_URL)
                    }
                },
                update = { webView = it }
            )
        }
    }
}

@Composable
private fun NavAction(
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    icon: @Composable () -> Unit
) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 4.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(1.dp)) {
            icon()
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}
